-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 35.240.147.88    Database: AcfDB
-- ------------------------------------------------------
-- Server version	5.7.14-google-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED='f50a6425-b26c-11e8-a386-42010a940010:1-2529495';

--
-- Table structure for table `ServiceTypeDim`
--

DROP TABLE IF EXISTS `ServiceTypeDim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ServiceTypeDim` (
  `ServiceType_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ServiceType` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ServiceType_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceTypeDim`
--

LOCK TABLES `ServiceTypeDim` WRITE;
/*!40000 ALTER TABLE `ServiceTypeDim` DISABLE KEYS */;
INSERT INTO `ServiceTypeDim` VALUES (1,'SERVICE_TYPE'),(2,'Meals'),(3,'Flexible Respite'),(4,'Other Food Services'),(5,'Allied Health and Therapy Services'),(6,'Social Support Individual'),(7,'Transport'),(8,'Personal Care'),(9,'Domestic Assistance'),(10,'Centre-based Respite'),(11,'Social Support Group'),(12,'Specialised Support Services'),(13,'Nursing'),(14,'Home maintenance'),(15,'Home modifications'),(16,'Short-Term Restorative Care'),(17,'Cottage Respite'),(18,'Client Care Coordination'),(19,'Case Management'),(20,'Assistance with Care and Housing'),(21,'Assessment'),(22,'Goods, equipment and assistive technology'),(23,'Transition Care'),(24,'National ATSI Aged Care Program'),(25,'Waitlist available');
/*!40000 ALTER TABLE `ServiceTypeDim` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-05  4:36:05
