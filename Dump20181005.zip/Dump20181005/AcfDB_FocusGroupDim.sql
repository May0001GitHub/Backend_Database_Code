-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 35.240.147.88    Database: AcfDB
-- ------------------------------------------------------
-- Server version	5.7.14-google-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED='f50a6425-b26c-11e8-a386-42010a940010:1-2529491';

--
-- Table structure for table `FocusGroupDim`
--

DROP TABLE IF EXISTS `FocusGroupDim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FocusGroupDim` (
  `FocusGroup_ID` int(11) NOT NULL AUTO_INCREMENT,
  `FocusGroup` varchar(400) DEFAULT NULL,
  `FocusGroupFromDataSet` varchar(400) DEFAULT NULL,
  `FocusGroupAbbr` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`FocusGroup_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FocusGroupDim`
--

LOCK TABLES `FocusGroupDim` WRITE;
/*!40000 ALTER TABLE `FocusGroupDim` DISABLE KEYS */;
INSERT INTO `FocusGroupDim` VALUES (1,'Cultural, spiritual or ethical food requirements','Caters for cultural, spiritual or ethical food requirements','Cultural Food'),(2,'Socially and financially disadvantaged people','Focus on socially and financially disadvantaged people','Disadvantaged'),(3,'People with a terminal illness','Special focus on people with a terminal illness','Terminal Illness'),(4,'Aboriginal and Torres Strait Islander people','Specific services for ATSI people','ATSI'),(5,'Lesbian, gay, bisexual and transgender people, intersex people','Specific services for LGBTI people','LGBTI'),(6,'Culturally and Linguistically Diverse Background People','Specific services for people with CALD backgrounds','CALD'),(7,'People with dementia','Specific services for people with dementia','Dementia');
/*!40000 ALTER TABLE `FocusGroupDim` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-05  4:36:00
