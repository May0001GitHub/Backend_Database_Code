-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 35.240.147.88    Database: AcfDB
-- ------------------------------------------------------
-- Server version	5.7.14-google-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED='f50a6425-b26c-11e8-a386-42010a940010:1-2529666';

--
-- Temporary view structure for view `view_agedCareHomeFocusGroupSuburb`
--

DROP TABLE IF EXISTS `view_agedCareHomeFocusGroupSuburb`;
/*!50001 DROP VIEW IF EXISTS `view_agedCareHomeFocusGroupSuburb`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_agedCareHomeFocusGroupSuburb` AS SELECT 
 1 AS `Street_Suburb`,
 1 AS `CALD`,
 1 AS `ATSI`,
 1 AS `Dementia`,
 1 AS `Disadvantaged`,
 1 AS `Terminal_Illness`,
 1 AS `Cultural_Food`,
 1 AS `LGBTI`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_helpAtHomeFocusGroupSuburb`
--

DROP TABLE IF EXISTS `view_helpAtHomeFocusGroupSuburb`;
/*!50001 DROP VIEW IF EXISTS `view_helpAtHomeFocusGroupSuburb`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_helpAtHomeFocusGroupSuburb` AS SELECT 
 1 AS `Street_Suburb`,
 1 AS `CALD`,
 1 AS `ATSI`,
 1 AS `Dementia`,
 1 AS `Disadvantaged`,
 1 AS `Terminal_Illness`,
 1 AS `Cultural_Food`,
 1 AS `LGBTI`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_agedCareHomeFocusGroupSuburb`
--

/*!50001 DROP VIEW IF EXISTS `view_agedCareHomeFocusGroupSuburb`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_agedCareHomeFocusGroupSuburb` AS select `loc`.`STREET_SUBURB` AS `Street_Suburb`,(case when (`fd`.`FocusGroupAbbr` = 'CALD') then `f`.`Total_Num_AgedCareHome` end) AS `CALD`,(case when (`fd`.`FocusGroupAbbr` = 'ATSI') then `f`.`Total_Num_AgedCareHome` end) AS `ATSI`,(case when (`fd`.`FocusGroupAbbr` = 'Dementia') then `f`.`Total_Num_AgedCareHome` end) AS `Dementia`,(case when (`fd`.`FocusGroupAbbr` = 'Disadvantaged') then `f`.`Total_Num_AgedCareHome` end) AS `Disadvantaged`,(case when (`fd`.`FocusGroupAbbr` = 'Terminal Illness') then `f`.`Total_Num_AgedCareHome` end) AS `Terminal_Illness`,(case when (`fd`.`FocusGroupAbbr` = 'Cultural Food') then `f`.`Total_Num_AgedCareHome` end) AS `Cultural_Food`,(case when (`fd`.`FocusGroupAbbr` = 'LGBTI') then `f`.`Total_Num_AgedCareHome` end) AS `LGBTI` from (((`AgedCareHomeFact` `f` join `AgedCareHomeFocusGroup_Bridge` `b`) join `LocationDim` `loc`) join `FocusGroupDim` `fd`) where ((`f`.`Home_ID` = `b`.`Home_ID`) and (`f`.`Location_ID` = `loc`.`LOCATION_ID`) and (`b`.`FocusGroup_ID` = `fd`.`FocusGroup_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_helpAtHomeFocusGroupSuburb`
--

/*!50001 DROP VIEW IF EXISTS `view_helpAtHomeFocusGroupSuburb`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_helpAtHomeFocusGroupSuburb` AS select `loc`.`STREET_SUBURB` AS `Street_Suburb`,(case when (`fd`.`FocusGroupAbbr` = 'CALD') then `f`.`Total_Num_HelpAtHome` end) AS `CALD`,(case when (`fd`.`FocusGroupAbbr` = 'ATSI') then `f`.`Total_Num_HelpAtHome` end) AS `ATSI`,(case when (`fd`.`FocusGroupAbbr` = 'Dementia') then `f`.`Total_Num_HelpAtHome` end) AS `Dementia`,(case when (`fd`.`FocusGroupAbbr` = 'Disadvantaged') then `f`.`Total_Num_HelpAtHome` end) AS `Disadvantaged`,(case when (`fd`.`FocusGroupAbbr` = 'Terminal Illness') then `f`.`Total_Num_HelpAtHome` end) AS `Terminal_Illness`,(case when (`fd`.`FocusGroupAbbr` = 'Cultural Food') then `f`.`Total_Num_HelpAtHome` end) AS `Cultural_Food`,(case when (`fd`.`FocusGroupAbbr` = 'LGBTI') then `f`.`Total_Num_HelpAtHome` end) AS `LGBTI` from (((`HelpAtHomeFact` `f` join `HelpAtHomeFocusGroup_Bridge` `b`) join `helpAtHomeLocationDim` `loc`) join `FocusGroupDim` `fd`) where ((`f`.`HelpAtHome_ID` = `b`.`HelpAtHome_ID`) and (`f`.`Location_ID` = `loc`.`LOCATION_ID`) and (`b`.`FocusGroup_ID` = `fd`.`FocusGroup_ID`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping routines for database 'AcfDB'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_cleanDuplicateFocusGroup_HelpAtHome` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_cleanDuplicateFocusGroup_HelpAtHome`()
BEGIN

-- Data Cleaning... To Remove Duplicate value of diverse needs (focus group)  in dataset
    

   
   DECLARE done1 BOOLEAN DEFAULT FALSE;  
    DECLARE vOutlet_Name VARCHAR (1000);
    DECLARE vDiverse_Needs VARCHAR (5000);
    
   
  DECLARE cur2 CURSOR FOR SELECT DISTINCT OUTLET_NAME, DIVERSE_NEEDS FROM Tbl_HelpAtHome_Dataset
   WHERE TRIM(STREET_STATE) LIKE '%VIC%'
   AND IFNULL(DIVERSE_NEEDS,'') !=''
   ORDER BY OUTLET_NAME;
   
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done1 = TRUE;
   
   OPEN cur2;
	read_loop2: LOOP
      
	  FETCH cur2 INTO vOutlet_Name, vDiverse_Needs ;
		
        IF done1 THEN
			LEAVE read_loop2;
		END IF;
        
		UPDATE HelpAtHome
		SET DIVERSE_NEEDS = vDiverse_Needs
		WHERE OUTLET_NAME LIKE vOutlet_Name
        AND HelpAtHome_ID >=1;
		

		
       
	END LOOP read_loop2;
	

	CLOSE cur2;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_compareAgedCareRooms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_compareAgedCareRooms`(IN firstHomeID Int(11), IN secondHomeID int(11) )
BEGIN

/*
 Retrive room information of two aged care homes for the purpose of comparison function

*/


 

	DECLARE vPCode Varchar(200);
	DECLARE done INT DEFAULT FALSE;
    DECLARE vhomeID int(11);
    DECLARE a varchar(200);
    DECLARE vRoomtype varchar(200);
	DECLARE vFirstHomeID int(11);
	DECLARE vCRoom_Type_ID INT(11);
	DECLARE vRoomtypeList varchar(400);
	DECLARE vMax_RadList varchar(200);
	DECLARE vMax_DapList varchar(200);
	DECLARE vRoomOccupancyList varchar(200);
	DECLARE vFundedList varchar(200);
    DECLARE vFunded varchar(200);
    DECLARE vMax_Rad varchar(200);
    DECLARE vMax_Dap varchar(200);
    DECLARE vRoomOccupancy varchar(200);

    -- Declare Cursor to loop room information of two aged care homes
    DECLARE cur1 CURSOR FOR
    SELECT DISTINCT r.Home_ID, r.Room_Type_ID, Commgovt_Subsidised, MIN(Max_RAD), MIN(Max_DAP), MIN(Max_Room_Occupancy)
    FROM AgedCareHomeRoom r, AgedCareHomeDim a
    WHERE a.Home_ID= r.Home_ID
	AND a.Home_ID IN ( firstHomeID, secondHomeID)
    GROUP BY r.Home_ID, r.Room_Type_ID, Commgovt_Subsidised
    ORDER BY r.Home_ID;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
	
    DROP TEMPORARY TABLE IF EXISTS temp_RoomCompare;
    
     /* Create Temporay Table */
	CREATE TEMPORARY TABLE temp_RoomCompare
    (Home_ID int(11),  
    Service_Name varchar(200) , 
    Room_TypeList varchar(400), 
    Max_RADList varchar(200), 
    Max_DapList varchar(200), 
    Max_RoomOccupancyList varchar (200), 
    FundedList varchar(200));
	
   /* Insert room information of two aged care home into the Temporay Table */
    INSERT INTO temp_RoomCompare (Home_ID, Service_Name)   
    SELECT Home_ID, Service_Name
    FROM AgedCareHomeDim
    WHERE Home_ID IN ( firstHomeID, secondHomeID);

	SET vRoomtypeList = '';
	SET vMax_RadList = '';
	SET vMax_DapList =  '';
	SET vRoomOccupancyList = '';
	SET vFundedList = '';    
    SET vFirstHomeID =0;
	SET SQL_SAFE_UPDATES = 0;
	
    -- Open cursor and read room information from the cursor
    OPEN cur1;

	  read_loop: LOOP
	  FETCH cur1 INTO vhomeID , vCRoom_Type_ID , vFunded, vMax_Rad, vMax_Dap, vRoomOccupancy;

		IF done THEN
		  LEAVE read_loop;
		END IF;
		SET a = (SELECT ROOM_TYPE FROM RoomTypeDim WHERE ROOM_TYPE_ID = vCRoom_Type_ID);
        
        
		-- string concatanation of room infromation including price, room occupancy and funded status
         if (vhomeID = vFirstHomeID) then
			SET vRoomtypeList = CONCAT(vRoomtypeList, ' , ', a);
            SET vMax_RadList = CONCAT(vMax_RadList, ' ', Format(vMax_Rad,2));
			SET vMax_DapList = CONCAT(vMax_DapList, ' , ', vMax_Dap);
			SET vRoomOccupancyList = CONCAT(vRoomOccupancyList, ' , ', vRoomOccupancy);
			SET vFundedList = CONCAT(vFundedList, ' , ', vFunded);

            
		else
			SET vRoomtypeList = a;
            SET vMax_RadList = Format(vMax_Rad,2);
			SET vMax_DapList =  vMax_Dap;
			SET vRoomOccupancyList = vRoomOccupancy;
			SET vFundedList = vFunded;
            SET vFirstHomeID= vhomeID;
		end if;

		-- Update room information of two aged care homes to temporay table
		UPDATE temp_RoomCompare
		SET Room_TypeList = vRoomtypeList, 
				Max_RADList =vMax_RadList, 
                Max_DapList =vMax_DapList ,
                Max_RoomOccupancyList = vRoomOccupancyList,
                FundedList =vFundedList
		WHERE Home_ID = vhomeID;
		
		
		 
	  END LOOP;
	  CLOSE cur1;
    

	-- Return room information of two aged care homes as result list
	SELECT Home_ID ,  Service_Name, Room_TypeList  , Max_RADList , Max_DapList , Max_RoomOccupancyList , FundedList 
    FROM temp_RoomCompare
    ORDER BY Room_TypeList ;
     

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createAgedCareHomeDatasetTable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createAgedCareHomeDatasetTable`()
BEGIN

	CREATE TABLE `Tbl_AgedCareHomes` (
	  `Sr` int(11) NOT NULL,
	  `SERVICE_NAME` varchar(200) DEFAULT NULL,
	  `ALT_NAME` varchar(200) DEFAULT NULL,
	  `PREVIOUS_NAME` varchar(200) DEFAULT NULL,
	  `LOCAL_NAME` varchar(200) DEFAULT NULL,
	  `DESCRIPTION` varchar(1000) DEFAULT NULL,
	  `COMMGOVT_SUBSIDISED` varchar(45) DEFAULT NULL,
	  `STREET_UNIT_NO` varchar(45) DEFAULT NULL,
	  `STREET_ST_ADDRESS` varchar(200) DEFAULT NULL,
	  `STREET_SUBURB` varchar(100) DEFAULT NULL,
	  `STREET_PCODE` varchar(45) DEFAULT NULL,
	  `STREET_STATE` varchar(45) DEFAULT NULL,
	  `BUS_UNIT_NO` varchar(45) DEFAULT NULL,
	  `BUS_ST_ADDRESS` varchar(45) DEFAULT NULL,
	  `BUS_SUBURB` varchar(45) DEFAULT NULL,
	  `BUS_PCODE` varchar(45) DEFAULT NULL,
	  `BUS_STATE` varchar(45) DEFAULT NULL,
	  `MAIN_PH_NUM` varchar(45) DEFAULT NULL,
	  `MAIN_FAX_NUM` varchar(45) DEFAULT NULL,
	  `MAIN_EMAIL_ADDR` varchar(45) DEFAULT NULL,
	  `WEBSITE` varchar(100) DEFAULT NULL,
	  `SERVICE_TYPE` varchar(45) DEFAULT NULL,
	  `ABN` varchar(45) DEFAULT NULL,
	  `APPROVED_PROVIDER` varchar(100) DEFAULT NULL,
	  `ACCREDITATION` varchar(45) DEFAULT NULL,
	  `ACCREDITATION_PERIOD` varchar(45) DEFAULT NULL,
	  `CERTIFICATION` varchar(45) DEFAULT NULL,
	  `NOTICE_OF_SANCTION` varchar(45) DEFAULT NULL,
	  `NOTICE_OF_NON_COMPLIANCE` varchar(45) DEFAULT NULL,
	  `AVAILABILITY` varchar(45) DEFAULT NULL,
	  `PARTICULAR_NEED_SERVICES` varchar(1000) DEFAULT NULL,
	  `ROOM_TITLE` varchar(100) DEFAULT NULL,
	  `ROOM_NAME` varchar(100) DEFAULT NULL,
	  `ROOM_TYPE` varchar(45) DEFAULT NULL,
	  `MAX_ROOM_OCCUPANCY` int(11) DEFAULT NULL,
	  `NUM_OF_ROOM_TYPES` varchar(45) DEFAULT NULL,
	  `MAX_RAD` decimal(6,2) DEFAULT NULL,
	  `MAX_DAP` decimal(6,2) DEFAULT NULL,
	  `PAYMENT_OPTIONS` varchar(5000) DEFAULT NULL,
	  `PAYMENT_EXAMPLE` varchar(1000) DEFAULT NULL,
	  `ROOM_DESC` varchar(500) DEFAULT NULL,
	  `ROOM_SIZE` varchar(45) DEFAULT NULL,
	  `COMMON_AREA_DESC` varchar(500) DEFAULT NULL,
	  `SPECIFIC_FEATURES` varchar(500) DEFAULT NULL,
	  `ADDITIONAL_CARE_INCL` varchar(100) DEFAULT NULL,
	  `ADDITIONAL_CARE_COST` varchar(100) DEFAULT NULL,
	  `EXTRA_SERVICE` varchar(100) DEFAULT NULL,
	  `EXTRA_SERVICE_FEE_AMOUNT` varchar(100) DEFAULT NULL,
	  PRIMARY KEY (`Sr`)
	) ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createAgedCareHomesDatasetTable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createAgedCareHomesDatasetTable`()
BEGIN

	CREATE TABLE `Tbl_AgedCareHomes` (
	  `Sr` int(11) NOT NULL,
	  `SERVICE_NAME` varchar(500) DEFAULT NULL,
	  `ALT_NAME` varchar(200) DEFAULT NULL,
	  `PREVIOUS_NAME` varchar(200) DEFAULT NULL,
	  `LOCAL_NAME` varchar(200) DEFAULT NULL,
	  `DESCRIPTION` varchar(4000) DEFAULT NULL,
	  `COMMGOVT_SUBSIDISED` varchar(45) DEFAULT NULL,
	  `STREET_UNIT_NO` varchar(45) DEFAULT NULL,
	  `STREET_ST_ADDRESS` varchar(200) DEFAULT NULL,
	  `STREET_SUBURB` varchar(100) DEFAULT NULL,
	  `STREET_PCODE` varchar(45) DEFAULT NULL,
	  `STREET_STATE` varchar(45) DEFAULT NULL,
	  `BUS_UNIT_NO` varchar(45) DEFAULT NULL,
	  `BUS_ST_ADDRESS` varchar(45) DEFAULT NULL,
	  `BUS_SUBURB` varchar(45) DEFAULT NULL,
	  `BUS_PCODE` varchar(45) DEFAULT NULL,
	  `BUS_STATE` varchar(45) DEFAULT NULL,
	  `MAIN_PH_NUM` varchar(45) DEFAULT NULL,
	  `MAIN_FAX_NUM` varchar(45) DEFAULT NULL,
	  `MAIN_EMAIL_ADDR` varchar(45) DEFAULT NULL,
	  `WEBSITE` varchar(100) DEFAULT NULL,
	  `SERVICE_TYPE` varchar(45) DEFAULT NULL,
	  `ABN` varchar(45) DEFAULT NULL,
	  `APPROVED_PROVIDER` varchar(100) DEFAULT NULL,
	  `ACCREDITATION` varchar(45) DEFAULT NULL,
	  `ACCREDITATION_PERIOD` varchar(45) DEFAULT NULL,
	  `CERTIFICATION` varchar(45) DEFAULT NULL,
	  `NOTICE_OF_SANCTION` varchar(45) DEFAULT NULL,
	  `NOTICE_OF_NON_COMPLIANCE` varchar(45) DEFAULT NULL,
	  `AVAILABILITY` varchar(45) DEFAULT NULL,
	  `PARTICULAR_NEED_SERVICES` varchar(3000) DEFAULT NULL,
	  `ROOM_TITLE` varchar(100) DEFAULT NULL,
	  `ROOM_NAME` varchar(100) DEFAULT NULL,
	  `ROOM_TYPE` varchar(45) DEFAULT NULL,
	  `MAX_ROOM_OCCUPANCY` int(11) DEFAULT NULL,
	  `NUM_OF_ROOM_TYPES` varchar(45) DEFAULT NULL,
	  `MAX_RAD` int(8) DEFAULT NULL,
	  `MAX_DAP` decimal(6,2) DEFAULT NULL,
	  `PAYMENT_OPTIONS` varchar(5000) DEFAULT NULL,
	  `PAYMENT_EXAMPLE` varchar(1000) DEFAULT NULL,
	  `ROOM_DESC` varchar(500) DEFAULT NULL,
	  `ROOM_SIZE` varchar(45) DEFAULT NULL,
	  `COMMON_AREA_DESC` varchar(500) DEFAULT NULL,
	  `SPECIFIC_FEATURES` varchar(500) DEFAULT NULL,
	  `ADDITIONAL_CARE_INCL` varchar(100) DEFAULT NULL,
	  `ADDITIONAL_CARE_COST` varchar(100) DEFAULT NULL,
	  `EXTRA_SERVICE` varchar(100) DEFAULT NULL,
	  `EXTRA_SERVICE_FEE_AMOUNT` varchar(100) DEFAULT NULL,
	  PRIMARY KEY (`Sr`)
	) ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createDBSchema` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createDBSchema`()
BEGIN

	-- The following two schema is for ETL process (extract, transform and load) from aged care home dataset and helpathome dataset
    -- Create tables to store data by extracting, transforming, loading (ETL process) from Aged Care Home Dataset
	CALL sp_createDBSchemaAgedCareHome();
	-- Create tables to store data by extracting, transforming, loading (ETL process) from Help At HOme Home Dataset
    CALL sp_createDBSchemaHelpAtHome();
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createDBSchemaAgedCareHome` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createDBSchemaAgedCareHome`()
BEGIN

    /* data from dataset csv is loaded into tho the tbl_AgedCarehomes.
	-- This is for creating database schema with ETL process (extract, transform and load data from aged care home dataset table)
    -- This data is retrived from agedcarehome dataset table 'tbl_AgedCarehomes'.*/

	-- Create AgedCareHomeDim table to store aged care home information in Victoria. 
	DROP TABLE IF EXISTS AgedCareHomeRoom;

	DROP TABLE IF EXISTS AgedCareHomeDim;


	CREATE TABLE `AgedCareHomeDim` (
	  `HOME_ID` int(11) NOT NULL AUTO_INCREMENT,
	  `SERVICE_NAME` varchar(200) DEFAULT NULL,
	  `DESCRIPTION` varchar(1000) DEFAULT NULL,
	  `COMMGOVT_SUBSIDISED` varchar(45) DEFAULT NULL,
	  `STREET_UNIT_NO` varchar(45) DEFAULT NULL,
	  `STREET_ST_ADDRESS` varchar(200) DEFAULT NULL,
	  `STREET_SUBURB` varchar(100) DEFAULT NULL,
	  `STREET_PCODE` varchar(45) DEFAULT NULL,
	  `STREET_STATE` varchar(45) DEFAULT NULL,
	  `MAIN_PH_NUM` varchar(45) DEFAULT NULL,
	  `MAIN_FAX_NUM` varchar(45) DEFAULT NULL,
	  `MAIN_EMAIL_ADDR` varchar(45) DEFAULT NULL,
	  `WEBSITE` varchar(100) DEFAULT NULL,
	  `SERVICE_TYPE` varchar(45) DEFAULT NULL,
	  `APPROVED_PROVIDER` varchar(45) DEFAULT NULL,
	  `ACCREDITATION` varchar(45) DEFAULT NULL,
	  `ACCREDITATION_PERIOD` VARCHAR(45) NULL,		
	  `CERTIFICATION` VARCHAR(45) NULL,		
	  `NOTICE_OF_SANCTION` VARCHAR(45) NULL,		
	  `NOTICE_OF_NON_COMPLIANCE` VARCHAR(45) NULL,	
	  `PARTICULAR_NEED_SERVICES` varchar(400) DEFAULT NULL,
	  Location_ID int(11),
	  FundedType_ID int(11),
     
	  PRIMARY KEY (`HOME_ID`)
	) ;

	-- Retrieve Aged Care Home Data from Data Set. Only retrive aged care homes in Victoria state
	INSERT INTO AgedCareHomeDim 
	(SERVICE_NAME, DESCRIPTION, COMMGOVT_SUBSIDISED, STREET_UNIT_NO, STREET_ST_ADDRESS, STREET_SUBURB, STREET_PCODE,
	STREET_STATE,MAIN_PH_NUM,  MAIN_FAX_NUM,MAIN_EMAIL_ADDR,WEBSITE,SERVICE_TYPE,APPROVED_PROVIDER,
	ACCREDITATION, ACCREDITATION_PERIOD,	CERTIFICATION,  NOTICE_OF_SANCTION,  NOTICE_OF_NON_COMPLIANCE,
		PARTICULAR_NEED_SERVICES
	)
	SELECT DISTINCT SERVICE_NAME, Description, COMMGOVT_SUBSIDISED, STREET_UNIT_NO, STREET_ST_ADDRESS, STREET_SUBURB, STREET_PCODE,
	STREET_STATE,MAIN_PH_NUM,  MAIN_FAX_NUM,MAIN_EMAIL_ADDR,WEBSITE,SERVICE_TYPE,APPROVED_PROVIDER,
	ACCREDITATION, ACCREDITATION_PERIOD,	CERTIFICATION, NOTICE_OF_SANCTION, NOTICE_OF_NON_COMPLIANCE,	
	PARTICULAR_NEED_SERVICES
	FROM Tbl_AgedCareHomes
	WHERE STREET_STATE = 'VIC'
	AND SERVICE_TYPE LIKE '%Permanent%';


	COMMIT;
    

	-- Aged Care Home Room Type from Data Set. Create Room Type Table.

	DROP TABLE IF EXISTS RoomTypeDim;

	CREATE TABLE RoomTypeDim (
	  ROOM_TYPE_ID int(11) NOT NULL AUTO_INCREMENT,
	   ROOM_TYPE varchar(45) DEFAULT NULL,
	   PRIMARY KEY (ROOM_TYPE_ID)
	  );
	   

	INSERT INTO RoomTypeDim
	( ROOM_TYPE)
	SELECT DISTINCT ROOM_TYPE
	FROM Tbl_AgedCareHomes
	WHERE STREET_STATE = 'VIC'
	AND SERVICE_TYPE LIKE '%Permanent%';

	-- Create Aged Care Home Room table to store room data from Dataset. One aged care home has more than one room of different room type.
	CREATE TABLE AgedCareHomeRoom
	(

	ROOM_ID 	INT(11) NOT NULL AUTO_INCREMENT,
	HOME_ID INT(11) NOT NULL,
	ROOM_NAME VARCHAR(100) DEFAULT NULL,
	 ROOM_TYPE_ID INT(11) DEFAULT NULL,
	 MAX_ROOM_OCCUPANCY VARCHAR(45) DEFAULT NULL,
	 MAX_RAD INT(8) DEFAULT NULL,
	 MAX_DAP DECIMAL(6,2) DEFAULT NULL,
	 ROOM_TYPE VARCHAR(45) DEFAULT NULL,
	 PRIMARY KEY (ROOM_ID),
	 FOREIGN KEY (HOME_ID) REFERENCES AgedCareHomeDim(HOME_ID)
	 );
	 
	INSERT INTO AgedCareHomeRoom
	(HOME_ID, ROOM_NAME, MAX_ROOM_OCCUPANCY, MAX_RAD, MAX_DAP, ROOM_TYPE_ID, ROOM_TYPE)
	SELECT a.HOME_ID, d.ROOM_NAME, d. MAX_ROOM_OCCUPANCY , d.MAX_RAD, d.MAX_DAP, r.Room_Type_ID, r.Room_Type
	FROM AgedCareHomeDim a , Tbl_AgedCareHomes d, RoomTypeDim r
	WHERE a.SERVICE_NAME = d.SERVICE_NAME
	AND d.Room_Type = r.Room_Type
	AND d.STREET_STATE = 'VIC'
	AND d.SERVICE_TYPE LIKE '%Permanent%';


	-- Cretate focus group table to store focus group that aged care home support. Focus group  data is retrived from data set. 
	DROP TABLE IF EXISTS FocusGroupDim;

	CREATE TABLE FocusGroupDim
	( FocusGroup_ID int(11) NOT NULL AUTO_INCREMENT,
	  FocusGroup varchar(400) DEFAULT NULL,
	  FocusGroupFromDataSet  varchar(400) DEFAULT NULL,
	  FocusGroupAbbr varchar (50) DEFAULT NULL, 
	  PRIMARY KEY (FocusGroup_ID)
	  );

	-- Transform Focus group data with full description because Some Focus group data in dataset is abbrebriated. 
	CALL sp_focusGroupTransformation();

	DROP TABLE IF EXISTS AgedCareHomeFocusGroup_Bridge;

	CREATE TABLE AgedCareHomeFocusGroup_Bridge
		 (
		   Home_ID int(11) ,
		   FocusGroup_ID int(11) ,
		   PRIMARY KEY (Home_ID, FocusGroup_ID)
		  );
		  
	-- To store the relationship of aged care home and its services for focus group. 
    -- One aged care home support services for more than one group. (CALD/Demenia/ATSI and so on) 
	CALL sp_createFocGroupAgedCareHomeBridge();

	DROP TABLE IF EXISTS LocationDim;

	CREATE TABLE LocationDim
	(LOCATION_ID INT(11)  NOT NULL AUTO_INCREMENT,
	STREET_PCODE VARCHAR(45),
	STREET_SUBURB VARCHAR (45),
	PRIMARY KEY (LOCATION_ID)
	);

	-- To store location (suburb) of aged care homes as a separte location table
	-- (Location Dimension table to link with Aged Care Home Fact table) so that total number of aged care home can be aggregated based on suburb location.
	INSERT INTO LocationDim (  STREET_SUBURB)
	SELECT DISTINCT  STREET_SUBURB
	FROM Tbl_AgedCareHomes
	WHERE STREET_STATE = 'VIC'
	AND SERVICE_TYPE LIKE '%Permanent%';




	/*Retrive maximun daily accommodation price from dataset and divide into four categories 
	so that users can filter aged care home data between the range of daily price they selected.*/
    
	DROP TABLE IF EXISTS DAPCategoryDim;

	CREATE TABLE DAPCategoryDim
	 (
	  DAPCategoryID int(11) NOT NULL AUTO_INCREMENT,
	   DAPCategoryDesc varchar(45) DEFAULT NULL,
	   FromDap Decimal(6,2) DEFAULT NULL,
	   ToDap Decimal(6,2) DEFAULT NULL,
	   PRIMARY KEY (DAPCategoryID)
	  );
	  
	INSERT INTO DAPCategoryDim
	(DapCategoryDesc, FromDap,ToDap)
	VALUES('Less than $ 100', 0, 99);

	INSERT INTO DAPCategoryDim
	(DapCategoryDesc, FromDap,ToDap)
	VALUES('$ 100- $ 200', 100, 200);

	INSERT INTO DAPCategoryDim
	(DapCategoryDesc, FromDap,ToDap)
	VALUES('$ 200- $ 300', 201, 300);

	INSERT INTO DAPCategoryDim
	(DapCategoryDesc, FromDap,ToDap)
	VALUES('Over $ 300', 301, 0);


	-- Retrive Funded type. Cretate Funded Type Dimension table
	DROP TABLE IF EXISTS FundedTypeDim;

	CREATE TABLE FundedTypeDim
	 (
	  FundedTypeID int(11) NOT NULL AUTO_INCREMENT,
	   FundedType varchar(45) DEFAULT NULL,
	   Funded varchar(5) DEFAULT NULL,
	   PRIMARY KEY (FundedTypeID)
	  );
	-- Dataset has 'yes or No' value only for funded information. 'Yes 'means funded by government, 'No' means private service.
	INSERT INTO FundedTypeDim
	(FundedType , Funded)
	values ('Commonwealth Government', 'Yes');

	INSERT INTO FundedTypeDim
	(FundedType ,Funded )
	values ('Private Service', 'No');

	-- update location ID to the agedcarehome table after creating location table
	UPDATE AgedCareHomeDim   a JOIN LocationDim l ON a.Street_Suburb = l.Street_Suburb 
	SET a.Location_ID = l.Location_ID
	WHERE a.home_ID >= 1 AND l.location_ID >=1;

	-- update FundedType ID to the agedcarehome table after creating FundetType dimension table

	UPDATE AgedCareHomeDim   a JOIN FundedTypeDim f ON a.Commgovt_Subsidised = f.Funded 
	SET a.FundedType_ID = f.FundedTypeID
	WHERE a.home_ID >= 1 AND f.FundedTypeID >=1;

	-- Create Aged Care Home Fact Table . To display aggregated data of total number of aged care homes based on location and focus group
	DROP TABLE IF EXISTS AgedCareHomeFact;

	CREATE TABLE AgedCareHomeFact
	 (
	   Home_ID int(11),
	   Location_ID int(11),
	   Total_Num_AgedCareHome  int(11), 
	   PRIMARY KEY (Home_ID,  Location_ID)
	  );
	  
	  
	  INSERT INTO AgedCareHomeFact ( Home_ID,   Location_ID, Total_Num_AgedCareHome)
	  SELECT a.Home_ID, loc.Location_ID, COUNT(a.HOME_ID)
	  FROM AgedCareHomeDim a JOIN  LocationDim loc ON a.location_ID = loc.location_ID
	  GROUP BY  a.Home_ID, loc.Location_ID;


COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createDBSchemaHelpAtHome` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createDBSchemaHelpAtHome`()
BEGIN

	-- Create table to store Help At Home provider data from dataset table
	DROP TABLE IF EXISTS HelpAtHome;

	CREATE TABLE `HelpAtHome` (
	  `HelpAtHome_ID` int(11) NOT NULL AUTO_INCREMENT,
	  `OUTLET_NAME` VARCHAR(500) NULL,		
		DIVERSE_NEEDS VARCHAR(5000) NULL, 
	  `ST_ADDR_PO_BOX` VARCHAR(200) NULL,		
	  `SUBURB_PHYSICAL` VARCHAR(100) NULL,		
	  `POST_CODE_PHYSICAL` VARCHAR(45) NULL,		
	  `STATE_PHYSICAL` VARCHAR(45) NULL,		
		Location_ID int(11),
	  
		PRIMARY KEY (`HelpAtHome_ID`)
	) ;

-- RetrieveHelp At Home Data from Data Set. Only retrive data of victoria.
	INSERT INTO HelpAtHome 
	(OUTLET_NAME,  ST_ADDR_PO_BOX,  SUBURB_PHYSICAL, STATE_PHYSICAL )
	SELECT  DISTINCT OUTLET_NAME,   STREET_ST_ADDRESS,  STREET_SUBURB, STREET_STATE
	FROM Tbl_HelpAtHome_Dataset
	WHERE TRIM(STREET_STATE) LIKE '%VIC%';

	commit;

	-- remove duplicate value of focus group (diverse needs) 

	call sp_cleanDuplicateFocusGroup_HelpAtHome();
  
  
	-- create location dimension table for help at home data
	  
	DROP TABLE IF EXISTS helpAtHomeLocationDim;

	CREATE TABLE helpAtHomeLocationDim
	(LOCATION_ID INT(11)  NOT NULL AUTO_INCREMENT,
	STREET_SUBURB VARCHAR (45),
	PRIMARY KEY (LOCATION_ID)
	);



	INSERT INTO helpAtHomeLocationDim (  STREET_SUBURB)
	SELECT DISTINCT  STREET_SUBURB
	FROM Tbl_HelpAtHome_Dataset
	WHERE TRIM(STREET_STATE) LIKE '%VIC%';
	  
	  
	UPDATE HelpAtHome   a JOIN helpAtHomeLocationDim l ON a.Suburb_Physical = l.Street_Suburb 
	SET a.Location_ID = l.Location_ID
	WHERE a.HelpAtHome_ID >= 1 AND l.location_ID >=1;



	-- Create bridge table for focus group with help at home relation

	DROP TABLE IF EXISTS HelpAtHomeFocusGroup_Bridge;

	CREATE TABLE HelpAtHomeFocusGroup_Bridge
		 (
		   HelpAtHome_ID int(11)  ,
		   FocusGroup_ID int(11) ,
		   PRIMARY KEY (HelpAtHome_ID, FocusGroup_ID)
		  );
		  
	CALL sp_createFocGroupHelpAtHomeBridge();


/*
-- Create Help At Home Fact Table To calculate aggreate value of help at home
DROP TABLE IF EXISTS HelpAtHomeFact;

CREATE TABLE HelpAtHomeFact
 (
   HelpAtHome_ID int(11),
   FocusGroup_ID  int(11),
   Location_ID int(11),
   Total_Num_HelpAtHome  int(11), 
   PRIMARY KEY (HelpAtHome_ID, FocusGroup_ID,Location_ID)
  );
  
  
  INSERT INTO HelpAtHomeFact (HelpAtHome_ID, FocusGroup_ID, Location_ID, Total_Num_HelpAtHome)
  SELECT DISTINCT a.HelpAtHome_ID, IFNULL(b.FocusGroup_ID,0), loc.Location_ID, COUNT(a.HelpAtHome_ID)
  FROM HelpAtHome a LEFT JOIN HelpAtHomeFocusGroup_Bridge b ON a.HelpAtHome_ID = b.HelpAtHome_ID  
  LEFT JOIN  helpAtHomeLocationDim loc ON  a.Location_ID = loc.Location_ID
  GROUP BY  a.HelpAtHome_ID,  IFNULL(b.FocusGroup_ID,0), loc.Location_ID;
  
  COMMIT;*/



	DROP TABLE IF EXISTS HelpAtHomeFact;

	CREATE TABLE HelpAtHomeFact
	 (
	   HelpAtHome_ID int(11),
	   Location_ID int(11),
	   Total_Num_HelpAtHome  int(11), 
	   PRIMARY KEY (HelpAtHome_ID, Location_ID)
	  );
	  
	  
	  INSERT INTO HelpAtHomeFact (HelpAtHome_ID,  Location_ID, Total_Num_HelpAtHome)
	  SELECT DISTINCT a.HelpAtHome_ID,  loc.Location_ID, COUNT(a.HelpAtHome_ID)
	  FROM HelpAtHome a  LEFT JOIN  helpAtHomeLocationDim loc ON  a.Location_ID = loc.Location_ID
	  GROUP BY  a.HelpAtHome_ID,   loc.Location_ID;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createFocGroupAgedCareHomeBridge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createFocGroupAgedCareHomeBridge`()
BEGIN

	
    -- To create a bridge table which store age care home and focus group (particular need services) relations
	DECLARE done1, done2 BOOLEAN DEFAULT FALSE;  

    DECLARE vOriginalStrLen int(4);
    DECLARE vParticular_Need_Services VARCHAR(400);
	DECLARE vHome_ID int(11);
    DECLARE vFocusGroup_ID int (11);
	DECLARE vFocusGroupCount INT(3);
    DECLARE vLoopCount INT(3);
    DECLARE vFocusGroupFromDataSet VARCHAR(400);
    
    
    
-- Retrive Particular Need Service (Focus Group)  fromdataset. This focsu group  will be separated line by line and stored record by record
    
   DECLARE cur2 CURSOR FOR SELECT DISTINCT Home_ID, 
   CASE WHEN Particular_Need_Services IS NULL or Particular_Need_Services = '' THEN 'empty'  ELSE Particular_Need_Services END AS FocusGroup 
   FROM AgedCareHomeDim;
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done1 = TRUE;
    
    DELETE FROM AgedCareHomeFocusGroup_Bridge WHERE Home_ID >= 1;

	
    
   OPEN cur2;

	  read_loop2: LOOP
      
	  FETCH cur2 INTO vHome_ID, vParticular_Need_Services ;
		
        IF done1 THEN
			LEAVE read_loop2;
		END IF;
        
		BLOCK1 : BEGIN
		
		DECLARE cur3 CURSOR FOR SELECT DISTINCT FocusGroup_ID , FocusGroupFromDataSet  FROM FocusGroupDim;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = TRUE;

		OPEN cur3;

			read_loop3: LOOP
			
			FETCH cur3 INTO vFocusGroup_ID, vFocusGroupFromDataSet ;

			IF done2 THEN
					SET done2= FALSE;
				  LEAVE read_loop3;
			END IF;
			
            -- Insert separted focsu group into record by record
		   IF  (INSTR(vParticular_Need_Services, vFocusGroupFromDataSet )) THEN

				INSERT INTO AgedCareHomeFocusGroup_Bridge
				(Home_ID, FocusGroup_ID )
				VALUES (vHome_ID, vFocusGroup_ID);		
                
		  END IF;
        
		END LOOP read_loop3;
		CLOSE cur3;

		END BLOCK1;	


       
	END LOOP read_loop2;

	CLOSE cur2;

	COMMIT;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createFocGroupHelpAtHomeBridge` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createFocGroupHelpAtHomeBridge`()
BEGIN

-- Retrive diver needs (focus group) which are stored in dataset in freetext. Those data are seprated line by line and will be stored in table record by record
	DECLARE done1, done2 BOOLEAN DEFAULT FALSE;  
    DECLARE vFocusGroup_ID int (11);
    DECLARE vFocusGroupFromDataSet VARCHAR(400);
	DECLARE vHelpAtHome_ID int(11);
    DECLARE vParticular_Need_Services VARCHAR(400);
    
   DECLARE cur2 CURSOR FOR SELECT DISTINCT HelpAtHome_ID, 
   CASE WHEN DIVERSE_NEEDS IS NULL or DIVERSE_NEEDS = '' THEN 'empty'  ELSE DIVERSE_NEEDS END AS FocusGroup 
   FROM HelpAtHome;
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done1 = TRUE;

	DELETE FROM HelpAtHomeFocusGroup_Bridge WHERE HelpAtHome_ID >=1;
    
   OPEN cur2;

	  read_loop2: LOOP
      
	  FETCH cur2 INTO vHelpAtHome_ID, vParticular_Need_Services ;
		
        IF done1 THEN
			LEAVE read_loop2;
		END IF;
        
		BLOCK1 : BEGIN
		
		DECLARE cur3 CURSOR FOR SELECT DISTINCT FocusGroup_ID , FocusGroupFromDataSet  FROM FocusGroupDim;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = TRUE;

		OPEN cur3;

			read_loop3: LOOP
			
			FETCH cur3 INTO vFocusGroup_ID, vFocusGroupFromDataSet ;

			IF done2 THEN
					SET done2= FALSE;
				  LEAVE read_loop3;
			END IF;
			-- insert seprated focus value to the bridge table record by record
		   IF  (INSTR(vParticular_Need_Services, vFocusGroupFromDataSet )) THEN

				INSERT INTO HelpAtHomeFocusGroup_Bridge
				(HelpAtHome_ID, FocusGroup_ID )
				VALUES (vHelpAtHome_ID, vFocusGroup_ID);		
                
		  END IF;
        
		END LOOP read_loop3;
		CLOSE cur3;

		END BLOCK1;	


       
	END LOOP read_loop2;

	CLOSE cur2;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_createHelpAtHomeDatasetTable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_createHelpAtHomeDatasetTable`()
BEGIN
	-- To store all data from Help At Home Dataset. 
    -- Create this table and upload dataset Help_At_Home.csv file into bucket of Cloud SQL.
    -- Then data from this dataset will be inserted automatically to this table "tbl_helpAthome_DataSet

	CREATE TABLE `Tbl_HelpAtHome_Dataset` (
	  

	`SR` INT NOT NULL,
	`OUTLET_NAME` VARCHAR(1000) NULL,	
	`DIVERSE_NEEDS` VARCHAR(5000) NULL,	
	`STREET_ST_ADDRESS` VARCHAR(500) NULL,	
	`STREET_SUBURB` VARCHAR(100) NULL,	
	`STREET_PCODE` VARCHAR(100) NULL,	
	`STREET_STATE` VARCHAR(100) NULL,	
	PRIMARY KEY (`SR`));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_focusGroupTransformation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_focusGroupTransformation`()
BEGIN

	-- To transform focus group data. Focus group data in data set are not user understandbal to show to user. It will be transformed into description
	DECLARE done INT DEFAULT FALSE;
	DECLARE done1 BOOLEAN DEFAULT FALSE;  
	DECLARE done2 BOOLEAN DEFAULT FALSE;  

    DECLARE vOriginalStrLen int(4);
    DECLARE vParticular_Need_Services VARCHAR(400);
	DECLARE vSplitStrLen int(4);
    DECLARE vSplitStr VARCHAR (400);
    DECLARE vAllSplitStrLen int(4);
	DECLARE vOrgUpdateStr VARCHAR(400);
    DECLARE vExistStr INT (4);
    DECLARE vHome_ID int(11);
    DECLARE vFocusGroup_ID int (11);
	DECLARE vFocusGroupCount INT(3);
    DECLARE vLoopCount INT(3);
    DECLARE vFocusGroupFromDataSet VARCHAR(400);

    
    
    DECLARE cur1 CURSOR FOR SELECT DISTINCT Particular_Need_Services , length(Particular_Need_Services) as originalLen FROM Tbl_AgedCareHomes  
														WHERE Particular_Need_Services IS NOT NULL
														AND STREET_STATE = 'VIC'
														AND SERVICE_TYPE LIKE '%Permanent%'
														AND IFNULL(Particular_Need_Services,'') !='';
                                                        
                                                        
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;




   DELETE FROM FocusGroupDim WHERE FocusGroup_ID >=1;


    OPEN cur1;

	  read_loop: LOOP
      
	  FETCH cur1 INTO vParticular_Need_Services, vOriginalStrLen ;

		IF done THEN
		  LEAVE read_loop;
		END IF;
        
        
	    SET vSplitStrLen =0;
        SET vAllSplitStrLen =0;
	
		SET vSplitStr='start';
        
        SET vOrgUpdateStr = vParticular_Need_Services;
        
        
        
        WHILE (IFNULL(vSplitStr,'') != '' ) DO
        
        		
                SET vSplitStr =  (SELECT DISTINCT TRIM( LEADING FROM SUBSTRING(vOrgUpdateStr,1, LOCATE(',',vOrgUpdateStr)-1)));
                
                IF vSplitStr = 'Caters for cultural' THEN
                
                    SET vSplitStr = 'Caters for cultural, spiritual or ethical food requirements';
				END IF;
                
				SET vSplitStrLen = (SELECT LENGTH(vSplitStr)) +2 ;
				SET vOrgUpdateStr =  (SELECT DISTINCT SUBSTRING(vOrgUpdateStr FROM vSplitStrLen ));
				SET vOrgUpdateStr = ( SELECT TRIM( LEADING FROM vOrgUpdateStr));
				
				SET vExistStr = (SELECT COUNT(FocusGroupFromDataSet) FROM FocusGroupDim WHERE FocusGroupFromDataSet LIKE vSplitStr);
				
				IF (IFNULL(vSplitStr,'') !='' )  AND vExistStr = 0 THEN
				
					INSERT INTO FocusGroupDim ( FocusGroupFromDataSet) 
					VALUES( vSplitStr );
				END IF;
                    
        END WHILE;

		
		 
	  END LOOP;
	  CLOSE cur1;
      
      -- Update Focus Group Description to be user understandable because Focus Group Data from Dataset is not user understandable

      
	 UPDATE FocusGroupDim
	 SET FocusGroup ='Culturally and Linguistically Diverse Background People', FocusGroupAbbr = 'CALD'
	 WHERE FocusGroupFromDataSet LIKE '%CALD%' AND FocusGroup_ID>0;

	UPDATE FocusGroupDim
	SET FocusGroup ='Aboriginal and Torres Strait Islander people' , FocusGroupAbbr = 'ATSI'
	WHERE FocusGroupFromDataSet LIKE '%ATSI%' AND FocusGroup_ID>0;


	UPDATE FocusGroupDim
	SET FocusGroup ='People with dementia',  FocusGroupAbbr = 'Dementia'
	WHERE FocusGroupFromDataSet LIKE '%dementia%' AND FocusGroup_ID>0;

	UPDATE FocusGroupDim
	SET FocusGroup ='Socially and financially disadvantaged people', FocusGroupAbbr = 'Disadvantaged'
	WHERE FocusGroupFromDataSet LIKE '%socially%' AND FocusGroup_ID>0;

		
	UPDATE FocusGroupDim
	SET FocusGroup ='People with a terminal illness' , FocusGroupAbbr = 'Terminal Illness'
	WHERE FocusGroupFromDataSet LIKE '%terminal%' AND FocusGroup_ID>0;
    
	UPDATE FocusGroupDim
	SET FocusGroup ='Cultural, spiritual or ethical food requirements' , FocusGroupAbbr = 'Cultural Food'
	WHERE FocusGroupFromDataSet LIKE '%ethical food%' AND FocusGroup_ID>0;
    
      
	UPDATE FocusGroupDim
	SET FocusGroup ='Lesbian, gay, bisexual and transgender people, intersex people' , FocusGroupAbbr = 'LGBTI'
	WHERE FocusGroupFromDataSet LIKE '%LGBTI%' AND FocusGroup_ID>0;
    
    
    

	COMMIT;

      

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getAgedCareHome` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getAgedCareHome`(IN suburbName varchar(45), IN focusGrpID int, IN fundedTID int,   IN DapCatID int)
BEGIN

/* Retrive aged care home data and return as a result list based on the criteria passed by client side*/

	DECLARE vFocusGroup Varchar(400);
    DECLARE vFunded Varchar (5);
	DECLARE vFrom_DAP decimal(6,2); 
	DECLARE vTo_DAP decimal(6,2); 


   
    

	-- SET vFocusGroup = (SELECT DISTINCT FocusGroupFromDataSet FROM FocusGroupDim WHERE FocusGroup_ID= focusGrpID);
-- 	SET vFunded = (SELECT DISTINCT Funded FROM FundedTypeDim WHERE FundedTypeID= fundedTID);
    SET vFrom_DAP = (SELECT  FromDap FROM DAPCategoryDim WHERE DapCategoryID= DapCatID);
	SET vTo_DAP = (SELECT  ToDap FROM DAPCategoryDim WHERE DapCategoryID= DapCatID);


    
	-- IF (focusGrpID = 4) THEN
            
		/*	SELECT DISTINCT a.Home_ID,
            CONCAT( a.Service_Name , '    \r\n ' , a.Street_Suburb , ' , ' ,  a.Street_State, ' ', a.Street_PCode ) AS ServiceName,
			a.Accreditation, 	a.Notice_Of_Non_Compliance,   a.Notice_Of_Sanction, 
            CONCAT('From ', r.maxDap_Desc ) as Price_Desc, 
	  	    CONCAT('From ' , r.maxRad_Desc) as Rad_Desc 
			 FROM  AgedCareHomeDim a, (SELECT Home_ID,  Min(Max_DAP) as  maxDap_Desc, Format(Min(Max_RAD),2) as maxRad_Desc  
																FROM AgedCareHomeRoom 
															    WHERE ((Max_DAP BETWEEN vFrom_Dap AND vTo_Dap)  OR DapCatID =0)
															    GROUP BY Home_ID) r
			WHERE a.Home_ID= r.Home_ID
			AND (a.Street_Suburb LIKE concat(suburbName, '%')  or (a.Street_PCode = suburbName ) or (suburbName =''))
			AND ((Particular_Need_Services LIKE  Concat('%', 'cultur' ,  '%'))  OR (Particular_Need_Services LIKE  Concat('%', 'CALD' ,  '%'))  )
			AND (a.Commgovt_Subsidised = vFunded OR fundedTID = 0);
            
   
			
         
	ELSE*/
    
		
		/*SELECT DISTINCT a.Home_ID, 
		CONCAT( a.Service_Name , '    \r\n ' , a.Street_Suburb , ' , ' ,  a.Street_State, ' ', a.Street_Pcode ) AS ServiceName , 
        a.Accreditation, 	a.Notice_Of_Non_Compliance,   a.Notice_Of_Sanction, 
		CONCAT('From ', r.maxDap_Desc ) as Price_Desc, 
		CONCAT('From ' , r.maxRad_Desc) as Rad_Desc 
		FROM  AgedCareHomeDim a,  (SELECT Home_ID,  Min(Max_DAP) as  maxDap_Desc, Format(Min(Max_RAD),2) as maxRad_Desc  
															FROM AgedCareHomeRoom 
															WHERE ((Max_DAP BETWEEN vFrom_DAP AND vTo_DAP)  OR DapCatID =0)
															GROUP BY Home_ID) r
		WHERE a.Home_ID= r.Home_ID
		AND (a.Street_Suburb LIKE concat(suburbName, '%')  or (a.Street_PCode = suburbName ) or (suburbName =''))
		AND ((Particular_Need_Services LIKE  Concat('%', vFocusGroup ,  '%'))  OR focusGrpID = 0)
		AND (a.Commgovt_Subsidised = vFunded OR fundedTID = 0);*/
        
	IF (focusGrpID = 0) THEN

		SELECT DISTINCT a.Home_ID, 
		CONCAT( a.Service_Name , '    \r\n ' , a.Street_Suburb , ' , ' ,  a.Street_State, ' ', a.Street_Pcode ) AS ServiceName , 
        a.Accreditation, 	a.Notice_Of_Non_Compliance,   a.Notice_Of_Sanction, 
		CONCAT('From ', r.maxDap_Desc ) as Price_Desc, 
		CONCAT('From ' , r.maxRad_Desc) as Rad_Desc 
		FROM  AgedCareHomeDim a   LEFT JOIN AgedCareHomeFocusGroup_Bridge b ON a.Home_ID = b.Home_ID JOIN
															(SELECT Home_ID,  Min(Max_DAP) as  maxDap_Desc, Format(Min(Max_RAD),2) as maxRad_Desc  
															FROM AgedCareHomeRoom 
															WHERE ((Max_DAP BETWEEN vFrom_DAP AND vTo_DAP)  OR DapCatID =0)
															GROUP BY Home_ID) r  ON a.Home_ID	= r.Home_ID
		WHERE (a.Street_Suburb LIKE concat(suburbName, '%')  or (a.Street_PCode = suburbName ) or (suburbName =''))
		AND ((b.FocusGroup_ID = focusGrpID)  OR focusGrpID = 0)
		AND (a.FundedType_ID = fundedTID OR fundedTID = 0);

	ELSE
        
        SELECT DISTINCT a.Home_ID, 
		CONCAT( a.Service_Name , '    \r\n ' , a.Street_Suburb , ' , ' ,  a.Street_State, ' ', a.Street_Pcode ) AS ServiceName , 
        a.Accreditation, 	a.Notice_Of_Non_Compliance,   a.Notice_Of_Sanction, 
		CONCAT('From ', r.maxDap_Desc ) as Price_Desc, 
		CONCAT('From ' , r.maxRad_Desc) as Rad_Desc 
		FROM  AgedCareHomeDim a   JOIN AgedCareHomeFocusGroup_Bridge b ON a.Home_ID = b.Home_ID JOIN
															(SELECT Home_ID,  Min(Max_DAP) as  maxDap_Desc, Format(Min(Max_RAD),2) as maxRad_Desc  
															FROM AgedCareHomeRoom 
															WHERE ((Max_DAP BETWEEN vFrom_DAP AND vTo_DAP)  OR DapCatID =0)
															GROUP BY Home_ID) r  ON a.Home_ID	= r.Home_ID
		WHERE (a.Street_Suburb LIKE concat(suburbName, '%')  or (a.Street_PCode = suburbName ) or (suburbName =''))
		AND ((b.FocusGroup_ID = focusGrpID)  OR focusGrpID = 0)
		AND (a.FundedType_ID = fundedTID OR fundedTID = 0);

  
     END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getAgedCareHomeDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getAgedCareHomeDetail`(IN homeID int)
BEGIN

/* Return detailed infromation of aged care home including address, contact phone and website*/

SELECT DISTINCT SERVICE_NAME,  DESCRIPTION as Description,
CONCAT(Street_St_Address , ' , ' , Street_Suburb , ' , ' , Street_PCode , ' , '  , Street_State ) AS ADDRESS ,
IF(Main_Ph_Num IS NULL or Main_Ph_Num = '', 'N/A', Main_Ph_Num) AS MAIN_PH_NUM,
IF(Main_Fax_Num IS NULL or Main_Fax_Num = '', 'N/A', Main_Fax_Num) AS MAIN_FAX_NUM,
IF(Main_Email_Addr IS NULL or Main_Email_Addr = '', 'N/A', Main_Email_Addr) AS MAIN_EMAIL_ADDR,
IF(Website IS NULL or Website = '', 'N/A', Website) AS WEBSITE,
IF(Particular_Need_Services IS NULL or Particular_Need_Services = '', 'N/A', Particular_Need_Services) AS Particular_Need_Services,
IF(Accreditation IS NULL or Accreditation = '', 'N/A', Accreditation) AS Accreditation,
IF(Notice_Of_Non_Compliance IS NULL or Notice_Of_Non_Compliance = '', 'N/A', Notice_Of_Non_Compliance) AS Notice_Of_Non_Compliance,
IF(Notice_Of_Sanction IS NULL or Notice_Of_Sanction = '', 'N/A', Notice_Of_Sanction) AS Notice_Of_Sanction,
IF(Accreditation_Period IS NULL or Accreditation_Period = '', 'N/A', Accreditation_Period) AS Accreditation_Period,
IF(Certification IS NULL or Certification = '', 'N/A', Certification) AS Certification
FROM AgedCareHomeDim
WHERE HOME_ID = homeID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getDapCategoryDim` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getDapCategoryDim`()
BEGIN

    -- Return a list of dail accommodation price category which was created during creating database schema
	SELECT DAPCategoryID, DapCategoryDesc FROM DAPCategoryDim;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getFocusGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getFocusGroup`()
BEGIN

-- Return a list of focus goup data which was created during creating database schema
SELECT FocusGroup_ID, FocusGroup  FROM FocusGroupDim;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getFundedTypeDim` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getFundedTypeDim`()
BEGIN

-- Return funded type data
SELECT * FROM FundedTypeDim;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getRoomList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getRoomList`(In homeID int)
BEGIN

-- Return a list of rooms provided by a particular aged care home
SELECT DISTINCT Room_Name, Room_Type, Max_Room_Occupancy, FORMAT(Max_RAD,2) AS Max_RAD, Max_Dap  as Max_Dap
FROM AgedCareHomeRoom 
WHERE Home_ID = homeID 
ORDER BY room_type;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getRoomTypeDim` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getRoomTypeDim`()
BEGIN

	-- Return a list of room type which was created during creating database schema
	SELECT * FROM RoomTypeDim;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getTotalAgedCareHome` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getTotalAgedCareHome`()
BEGIN

	-- Get total number of aged care homes in victoria (to show at dasboard factsumary)
	SELECT COUNT( Home_ID) as Total_AgedCareHomes
    FROM AgedCareHomeFact;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getTotalAgedCareHome_ByFocusGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getTotalAgedCareHome_ByFocusGroup`()
BEGIN

	-- Return total number of AGed Care Homes in Victoria Group By different FocusGroup
    
    	SELECT g.FocusGroupAbbr, count(Total_Num_AgedCareHome) as Total_AgedCareHomes
		FROM  AgedCareHomeFact f,  AgedCareHomeFocusGroup_Bridge b, FocusGroupDim g
		WHERE f.Home_ID = b.Home_ID
		AND b.FocusGroup_ID = g.FocusGroup_ID
		GROUP BY g.FocusGroupAbbr;
                                                        
                                                        
	
    	
                                                        

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getTotalAgedCareHome_ByFocusGroup_Suburb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getTotalAgedCareHome_ByFocusGroup_Suburb`()
BEGIN
           
-- retrieve total number of AGed Care Homes in victoria by focus group and suburb
	SELECT totalHomesBySuburbNoFocusGroup.Street_Suburb as Street_Suburb,
				   coalesce( totalHomesBySuburbNoFocusGroup.TotalinSuburb,0) as TotalinSuburb, 
                   coalesce( totHomesBySuburbWithFocusGroup.CALD,0) as  CALD, 
                   coalesce( totHomesBySuburbWithFocusGroup.ATSI,0) as ATSI, 
                   coalesce( totHomesBySuburbWithFocusGroup.Dementia,0) as Dementia , 
                   coalesce( totHomesBySuburbWithFocusGroup.Disadvantaged, 0) as Disadvantaged, 
                   coalesce( totHomesBySuburbWithFocusGroup.Terminal_Illness,0)  as Terminal_Illness, 
                   coalesce( totHomesBySuburbWithFocusGroup.Cultural_Food, 0) as Cultural_Food, 
                   coalesce( totHomesBySuburbWithFocusGroup.LGBTI,0) as LGBTI
    FROM  
	(SELECT 
						count(Home_ID) as TotalinSuburb, 
                        Street_Suburb 
                        FROM AgedCareHomeDim
                        GROUP BY Street_Suburb 
	) totalHomesBySuburbNoFocusGroup  
    LEFT JOIN
	(SELECT 
						Street_Suburb,
						sum(coalesce(CALD,0)) as CALD,
						sum(coalesce(ATSI, 0)) as ATSI,
						sum(coalesce(Dementia, 0)) as Dementia,
						sum(coalesce(Disadvantaged, 0)) as Disadvantaged,
						sum(coalesce(Terminal_Illness, 0)) as Terminal_Illness,
						sum(coalesce(Cultural_Food, 0)) as 'Cultural_Food',
						sum(coalesce(LGBTI, 0)) as LGBTI
						FROM view_agedCareHomeFocusGroupSuburb
						GROUP BY Street_Suburb
                        ) totHomesBySuburbWithFocusGroup
		ON totalHomesBySuburbNoFocusGroup.Street_Suburb = totHomesBySuburbWithFocusGroup.Street_Suburb;
    
                                                        
                                                        
                                                        
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getTotalHelpAtHome` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getTotalHelpAtHome`()
BEGIN

	-- Return total number of help at home providers in Victoria

	SELECT Count(HelpAtHome_ID) as HelpAtHomeFact
    FROM HelpAtHome;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getTotalHelpAtHome_ByFocusGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getTotalHelpAtHome_ByFocusGroup`()
BEGIN
	-- Return total number of HelpAtHome Providers in Victoria  Group By different FocusGroup
    	SELECT g.FocusGroupAbbr, SUM(Total_Num_HelpAtHome) as Total_HelpAtHomes
		FROM HelpAtHomeFact f,  HelpAtHomeFocusGroup_Bridge b,  FocusGroupDim g
		WHERE f.HelpAtHome_ID = b.HelpAtHome_ID
		AND b.FocusGroup_ID = g.FocusGroup_ID
		GROUP BY g.FocusGroupAbbr;
                                                        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_getTotalHelpAtHome_ByFocusGroup_Suburb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sp_getTotalHelpAtHome_ByFocusGroup_Suburb`()
BEGIN

-- retrieve total number of help at home providers in victoria by focus group and suburb
	SELECT totalHomesBySuburbNoFocusGroup.Suburb_Physical as Street_Suburb,
				   coalesce( totalHomesBySuburbNoFocusGroup.TotalinSuburb,0) as TotalinSuburb, 
                   coalesce( totHomesBySuburbWithFocusGroup.CALD,0) as  CALD, 
                   coalesce( totHomesBySuburbWithFocusGroup.ATSI,0) as ATSI, 
                   coalesce( totHomesBySuburbWithFocusGroup.Dementia,0) as Dementia , 
                   coalesce( totHomesBySuburbWithFocusGroup.Disadvantaged, 0) as Disadvantaged, 
                   coalesce( totHomesBySuburbWithFocusGroup.Terminal_Illness,0)  as Terminal_Illness, 
                   coalesce( totHomesBySuburbWithFocusGroup.Cultural_Food, 0) as Cultural_Food, 
                   coalesce( totHomesBySuburbWithFocusGroup.LGBTI,0) as LGBTI
    FROM  
	(SELECT 
						count(HelpAtHome_ID) as TotalinSuburb, 
                        Suburb_Physical 
                        FROM HelpAtHome
                        GROUP BY Suburb_Physical 
	) totalHomesBySuburbNoFocusGroup  
    LEFT JOIN
	(SELECT 
						Street_Suburb,
						sum(coalesce(CALD,0)) as CALD,
						sum(coalesce(ATSI, 0)) as ATSI,
						sum(coalesce(Dementia, 0)) as Dementia,
						sum(coalesce(Disadvantaged, 0)) as Disadvantaged,
						sum(coalesce(Terminal_Illness, 0)) as Terminal_Illness,
						sum(coalesce(Cultural_Food, 0)) as 'Cultural_Food',
						sum(coalesce(LGBTI, 0)) as LGBTI
						FROM view_helpAtHomeFocusGroupSuburb
						GROUP BY Street_Suburb
                        ) totHomesBySuburbWithFocusGroup
		ON totalHomesBySuburbNoFocusGroup.Suburb_Physical = totHomesBySuburbWithFocusGroup.Street_Suburb;
    
                                                        
                                                        
	


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-05  4:39:05
